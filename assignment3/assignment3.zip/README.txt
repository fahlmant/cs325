Anthony Miller
Taylor Fahlman
Group 3

Requires python 2
Steps to run:
1. run 'python assignment3.py' in a shell
